<?php

$numeros = array();
for ($i=0; $i <=15 ; $i++){
	$numeros[]=rand(1,1000);
}

foreach ($numeros as $key => $numeros ){
	if ($numeros==0) {
		echo 'A posiçao é: ' .$key. 'os numeros sao: '.$numeros.' ';
	}
	else
	{
		echo 'A posiçao é: ' .$key.'os numeros: '.$numeros.' ';
	}
	echo "<br>";
}
?>