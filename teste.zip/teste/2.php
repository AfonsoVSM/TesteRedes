<?php

$soma = 0;
$a;
$b;
function adicionar($a,$b){
	return $a+$b;
}
$soma = adicionar (2,6);
echo $soma;