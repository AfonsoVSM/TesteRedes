<?php

$dias = array('seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'domingo');
echo $dias[0];
echo '<br>';
$meses = array('jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez');
echo $meses[0];