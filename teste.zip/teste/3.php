<?php
$dia = array('0-domingo', '1-seg', '2-ter', '3-qua', '4-qui', '5-sex', '6-sab');

echo $dia[0];


?>