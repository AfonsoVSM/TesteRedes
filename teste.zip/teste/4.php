<?php
$mes = 12;
switch ($mes){
    case '1':
        print('Jan');
        break;
    case '2':
    print('Fev');
    break;

    case '3':
        print('Mar');
        break;

    case '4':
        print('Abr');
        break;

    case '5':
        print('Mai');
        break;

    case '6':
        print('Jun');
        break;

    case '7':
            print('Jul');
            break;

    case '8':
            print('Ago');
            break;

    case '9':
            print('Set');
            break;

    case '10':
            print('Out');
            break;

    case '11':
            print('Nov');
            break;

    case '12':
            print('Dez');
            break;

    default:
        echo 'Erro ao validar o dia da semana';
        break;
}
?>