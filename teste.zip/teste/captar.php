<?php
    $DiasSemana = $_POST["txt_DiasSemana"];
    $MesesAno = $_POST["txt_MesesAno"];
    echo "DiasSemana: " .$DiasSemana. "<br>";
    echo "MesesAno: " .$MesesAno;