<form action="captar.php" method="POST">
    DiasSemana: <input type="text" name="txt_DiasSemana" size="5"> <br><br>
    MesesAno: <input type="text" name="txt_MesesAno" size="5"> <br><br>
    <input type="submit" value="Submeter dados">
</form>